# R7 audit bundle

This bundle contains the R7 implementation, tests, audit matrix, diagnostics, and source metadata from the repository branch `r7-governor-corrections` at commit `7c08ad5`.

## Where the implementation lives

- `engine/r7_engine.py`: R7 integration mixin, native Engine B/C factory, allocation, admission, exits, checkpoints, and telemetry.
- `engine/r7_state.py`: R7 control configuration and the 11 governor parameters.
- `engine/r7_coordinated_controller.py`: per-symbol AVR/reference/governor/FSM pipeline.
- `engine/r7_market_governor.py`: closed-loop PID governor, anti-windup, slew, and response lag.
- `engine/r7_market_avr.py`: market AVR participation loop.
- `engine/r7_allocator.py`: demand-aware portfolio allocation and pending-exposure handling.
- `engine/r7_features.py`: causal feature extraction.
- `engine/r6_avr_core.py` and `engine/r6_turbine_governor.py`: preserved physical AVR/R6 components.

## Where the implementation tests live

The `tests/` directory contains the R7 FSM, governor, allocator, AVR, feature, checkpoint, integration, normal-exit, and R6 regression tests.

## Where the audit evidence lives

- `audit/R7_57_requirement_acceptance.xlsx`: 57-point acceptance matrix.
- `audit/R7_57_requirement_acceptance.md`: readable matrix export.
- `audit/R7_AUDIT_REPORT_20261017.md`: current audit report and evidence status.
- `diagnostics/R7_CONTROLLER_DIAGNOSTIC_LATEST.json`: controller stress diagnostic.
- `diagnostics/R7_LATEST_SOURCE_20261017-175715.tar.gz`: source archive supplied for the audit.
- `metadata/`: Git state, source metadata, uncommitted diff, and SHA-256 manifest.

The bundle is evidence-oriented. It does not claim that the blocked full Engine A/B/C replay, native journal checkpoint integration, or Gate C historical comparison has been completed.
