"""One predeclared OHLCV breakout-continuation alpha, shadow-only.

This is intentionally narrow: it is a research hypothesis, not an optimizer.
It requires an intraday 20-bar breakout, directional EMA slope, session-VWAP
alignment and expanding volume, then uses the shared conservative next-bar
fill/cost/terminal-bar model.
"""
from __future__ import annotations
from typing import Any, Dict
import numpy as np
import pandas as pd
import talib
from revision2_external.study_entry_shadow import StudyEntryShadowLedger

class BreakoutContinuationShadow:
    def __init__(self, ledger: StudyEntryShadowLedger) -> None: self.ledger=ledger
    def observe_precomputed(self, symbol:str,index:int,timestamp:object,bar:Any,atr:float,metrics:Dict[str,float])->None:
        """Same rule as ``observe`` using causal per-session indicator arrays."""
        close=float(metrics['close']);prior_high=float(metrics['prior_high']);prior_low=float(metrics['prior_low'])
        vwap=float(metrics['session_vwap']);ema=float(metrics['ema20']);ema_lag=float(metrics['ema20_lag4']);vol_ratio=float(metrics['volume_ratio'])
        side=None
        if close>prior_high and close>vwap and ema>ema_lag and vol_ratio>=1.2: side='BUY'
        elif close<prior_low and close<vwap and ema<ema_lag and vol_ratio>=1.2: side='SELL'
        if side is None:return
        scale=max(float(atr),1e-6); setup_extreme=float(close-.75*scale if side=='BUY' else close+.75*scale)
        direction = 1.0 if side == 'BUY' else -1.0
        level = prior_high if side == 'BUY' else prior_low
        obs={'timestamp':str(timestamp),'symbol':symbol,'index':index,'alpha':'breakout_continuation_v1','side':side,'close':close,'prior_20_high':prior_high,'prior_20_low':prior_low,'session_vwap':vwap,'ema20':ema,'volume_ratio':vol_ratio,'breakout_extension_atr':direction*(close-level)/scale,'vwap_distance_atr':direction*(close-vwap)/scale,'ema_slope_atr':direction*(ema-ema_lag)/scale}
        self.ledger.observations.append(obs);self.ledger.schedule(symbol=symbol,index=index,side=side,setup_extreme=setup_extreme,atr=scale,observation=obs)
    def observe(self, symbol:str,index:int,timestamp:object,bar:Any,history:pd.DataFrame,atr:float)->None:
        if len(history)<25:return
        close=history.close.to_numpy(float);high=history.high.to_numpy(float);low=history.low.to_numpy(float);volume=history.volume.to_numpy(float)
        ema=talib.EMA(close,timeperiod=20);vol_ref=max(float(np.median(volume[-21:-1])),1e-12);vol_ratio=float(volume[-1]/vol_ref)
        vwap=float(np.sum(close*volume)/max(np.sum(volume),1e-12)); prior_high=float(np.max(high[-21:-1]));prior_low=float(np.min(low[-21:-1]))
        side=None
        if close[-1]>prior_high and close[-1]>vwap and ema[-1]>ema[-5] and vol_ratio>=1.2: side='BUY'
        elif close[-1]<prior_low and close[-1]<vwap and ema[-1]<ema[-5] and vol_ratio>=1.2: side='SELL'
        if side is None:return
        # Fill occurs only next bar; this setup chooses a one-ATR intended
        # stop geometry relative to the decision close, then records actual
        # next-open risk after conservative fill.
        scale=max(float(atr),1e-6); setup_extreme=float(close[-1]-.75*scale if side=='BUY' else close[-1]+.75*scale)
        direction = 1.0 if side == 'BUY' else -1.0
        level = prior_high if side == 'BUY' else prior_low
        obs={'timestamp':str(timestamp),'symbol':symbol,'index':index,'alpha':'breakout_continuation_v1','side':side,'close':float(close[-1]),'prior_20_high':prior_high,'prior_20_low':prior_low,'session_vwap':vwap,'ema20':float(ema[-1]),'volume_ratio':vol_ratio,'breakout_extension_atr':direction*(float(close[-1])-level)/scale,'vwap_distance_atr':direction*(float(close[-1])-vwap)/scale,'ema_slope_atr':direction*(float(ema[-1])-float(ema[-5]))/scale}
        self.ledger.observations.append(obs);self.ledger.schedule(symbol=symbol,index=index,side=side,setup_extreme=setup_extreme,atr=scale,observation=obs)
